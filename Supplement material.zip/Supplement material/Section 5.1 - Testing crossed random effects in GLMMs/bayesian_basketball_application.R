#In this script we will check whether the basketball data from
#the book Beyong Multiple Linear Regression could potentially be
#use for the application in the paper
library(rstan)
library(lme4)
library(EBF)

refdata <- read.csv("basketball0910.csv")

##################################################################################################
##################################################################################################
##################################################################################################

#First let's start showing that the model in the Roback & Legler 2021 results in a model that 
#fails to converge.

#Model b3 from the book (see line 920 from the source code https://github.com/proback/BeyondMLR/blob/master/11-Generalized-Linear-Multilevel-Models.Rmd)
model.b3 <- glmer(foul.home ~ foul.diff + (1|game) +
                    (1|hometeam) + (1|visitor) + (0+foul.diff|game) +
                    (0+foul.diff|hometeam) + (0+foul.diff|visitor), 
                  family = binomial, data = refdata)
summary(model.b3)

##################################################################################################
##################################################################################################
##################################################################################################

df <- refdata[,c("game","foul.home","hometeam","visitor","foul.diff")]

#Changing the character vector representing teams to numeric
all_teams <- c(df$hometeam, df$visitor)
team_factor <- factor(all_teams)
# Create the numeric representations for home and visitor teams
home_team_numeric <- as.numeric(team_factor[1:length(df$hometeam)])
visitor_team_numeric <- as.numeric(team_factor[(length(df$hometeam) + 1):length(all_teams)])

df$hometeam <- home_team_numeric
df$visitor <- visitor_team_numeric

#Standardizing foul differential
df$foul.diff <- (df$foul.diff - mean(df$foul.diff))/sd(df$foul.diff)

data <- list(N = nrow(df),
             N_games = length(unique(df$game)),
             N_home = length(unique(df$hometeam)),
             N_visitor = length(unique(df$visitor)),
             y = df$foul.home,
             game = df$game,
             home = df$hometeam,
             visitor = df$visitor,
             foul_diff = df$foul.diff)

#Loading stan model
model <- stan_model(file = "cross_random_effects_basketball.stan")

#Sampling
set.seed(123)
t1 <- Sys.time()
fit <- sampling(model, data = data, iter = 50000, chains = 1,
                control = list(adapt_delta = 0.9,
                               max_treedepth = 15))
(t2 <- Sys.time() - t1)

###################################################################################
###################################################################################
###################################################################################

#Extract posterior draws from fitted object
pars <- rstan::extract(fit)

###################################################################################
###################################################################################
###################################################################################

#EBFs for game level
theta1 <- apply(pars$theta_1, c(2,3), mean)
colnames(theta1) <- c('intercept', 'foul.diff')
sig1 <- lapply(1:2, function(x) cov(pars$theta_1[,,x]))
tau1 <- apply(pars$tau_1,2,mean)
EBF(theta1, sig1, tau1)
# or obtain EBFs using dmvnorm
J <- nrow(theta1)
dmvnorm(rep(0,J),mean=theta1[,1],sigma=sig1[[1]],log=TRUE) -
  dmvnorm(rep(0,J),mean=rep(0,J),sigma=tau1[1]*diag(J),log=TRUE)
dmvnorm(rep(0,J),mean=theta1[,2],sigma=sig1[[2]],log=TRUE) -
  dmvnorm(rep(0,J),mean=rep(0,J),sigma=tau1[2]*diag(J),log=TRUE)

###################################################################################
###################################################################################
###################################################################################

# EBFs for home team level
theta2 <- apply(pars$theta_2, c(2,3), mean)
colnames(theta2) <- c('intercept', 'foul.diff')
sig2 <- lapply(1:2, function(x) cov(pars$theta_2[,,x]))
tau2 <- apply(pars$tau_2,2,mean)
EBF(theta2, sig2, tau2)
# or obtain EBFs using dmvnorm
J <- nrow(theta2)
dmvnorm(rep(0,J),mean=theta2[,1],sigma=sig2[[1]],log=TRUE) -
  dmvnorm(rep(0,J),mean=rep(0,J),sigma=tau2[1]*diag(J),log=TRUE)
dmvnorm(rep(0,J),mean=theta2[,2],sigma=sig2[[2]],log=TRUE) -
  dmvnorm(rep(0,J),mean=rep(0,J),sigma=tau2[2]*diag(J),log=TRUE)

###################################################################################
###################################################################################
###################################################################################

# EBFs for home team level
theta3 <- apply(pars$theta_3, c(2,3), mean)
colnames(theta3) <- c('intercept', 'foul.diff')
sig3 <- lapply(1:2, function(x) cov(pars$theta_3[,,x]))
tau3 <- apply(pars$tau_3,2,mean)
EBF(theta3, sig3, tau3)
# or obtain EBFs using dmvnorm
J <- nrow(theta3)
dmvnorm(rep(0,J),mean=theta3[,1],sigma=sig3[[1]],log=TRUE) -
  dmvnorm(rep(0,J),mean=rep(0,J),sigma=tau3[1]*diag(J),log=TRUE)
dmvnorm(rep(0,J),mean=theta3[,2],sigma=sig3[[2]],log=TRUE) -
  dmvnorm(rep(0,J),mean=rep(0,J),sigma=tau3[2]*diag(J),log=TRUE)

###################################################################################
###################################################################################
###################################################################################

# EBF for testing full model against a model that excludes all three foul differential random effects
# get combine all random effects
est_foul.diffs <- c(theta1[,2],theta2[,2],theta3[,2])
# get joint covariance matrix
cov_foul.diffs <- cov(cbind(pars$theta_1[,,2],pars$theta_2[,,2],pars$theta_3[,,2]))
taureps <- c(rep(tau1[2],length(theta1[,2])),rep(tau2[2],length(theta2[,2])),rep(tau3[2],length(theta3[,2])))
# compute EBF
J <- length(est_foul.diffs)
dmvnorm(rep(0,J),mean=est_foul.diffs,sigma=cov_foul.diffs,log=TRUE) -
  dmvnorm(rep(0,J),mean=rep(0,J),sigma=diag(taureps),log=TRUE)
# which is close to the sum of the EBFs of the separate EBFs for foul differential random effects
#(but exactly because of using the joint posterior covariance matrix)
13.62701 + 5.220275 + 4.646174

###################################################################################
###################################################################################
###################################################################################


df_ebf <- 
data.frame(
  "parameter" = rep(c('intercept', 'foul.diff'),3),
  "log_EBF_mean" = c(game_mean$EBF, home_mean$EBF, visitor_mean$EBF)
)
df_ebf[c(2,4,6,1,3,5),]

###################################################################################
###################################################################################
###################################################################################

tau1 <- apply(pars$tau_1,2,mean)
tau2 <- apply(pars$tau_2,2,mean)
tau3 <- apply(pars$tau_3,2,mean)

ci1 <- apply(pars$tau_1, 2, function(i) quantile(i, probs = c(0.025, 0.975)))
ci2 <- apply(pars$tau_2, 2, function(i) quantile(i, probs = c(0.025, 0.975)))
ci3 <- apply(pars$tau_3, 2, function(i) quantile(i, probs = c(0.025, 0.975)))


df_var <-
  data.frame(
    "parameter" = rep(c('foul.diff', 'intercept'),3),
    "mean_estimate" = c(tau1, tau2, tau3),
    "CI_lower" = c(ci1[1,], ci2[1,], ci3[1,]),
    "CI_upper" = c(ci1[2,], ci2[2,], ci3[2,])
  )
df_var[c(2,4,6,1,3,5),]

xtable::xtable(df_var[c(2,4,6,1,3,5),], digits = 4)

###################################################################################
###################################################################################
###################################################################################

nomes <- c("foul_diff-game", "intercept-game",
           "foul_diff-home", "intercept-home",
           "foul_diff-visitor", "intercept-visitor")
tau <- cbind(pars$tau_1, pars$tau_2, pars$tau_3)

par(mfrow = c(2,3))
plot(tau[,2],
     type = "l",
     main = expression(tau[1]^2),
     xlab = "samples",
     ylab = "values")
plot(tau[,1],
     type = "l",
     main = expression(tau[1*"*"]^2),
     xlab = "samples",
     ylab = "values")
###################################
plot(tau[,4],
     type = "l",
     main = expression(tau[2]^2),
     xlab = "samples",
     ylab = "values")
plot(tau[,3],
     type = "l",
     main = expression(tau[2*"*"]^2),
     xlab = "samples",
     ylab = "values")
##################################
plot(tau[,6],
     type = "l",
     main = expression(tau[3]^2),
     xlab = "samples",
     ylab = "values")
plot(tau[,5],
     type = "l",
     main = expression(tau[3*"*"]^2),
     xlab = "samples",
     ylab = "values")

###################################################################################
###################################################################################
###################################################################################

#Plotting the random effects posterior distributions

###################################################################################
###################################################################################
###################################################################################


par(mfrow = c(3,2))
#FOUL DIFF GAME LEVEL
x <- seq(-2, 2, length = 100)
y <- dnorm(x, mean = theta1[1,1], sd = sqrt(sig1[[1]][1,1]))
plot(x, y, type = "l", main = "Foul differential - game level", cex.main = 1.5,
     xlab = "values", ylab = "density", ylim = c(0,1.5))
for(i in 2:340){
  y <- dnorm(x, mean = theta1[i,1], sd = sqrt(sig1[[1]][i,i]))
  lines(x, y, type = "l")
}
y2 <- dnorm(x, mean = 0, sd = sqrt(tau1[1]))
lines(x, y2, type = "l", col = 2, lwd = 5)
#legend(x = 0.025, y = 40, legend = c("posterior", "prior"), col = c(1,2), lwd = 2, bty = "n", cex = 1.3)

#INTERCEPT GAME LEVEL
x <- seq(-.8, .8, length = 100)
y <- dnorm(x, mean = theta1[1,2], sd = sqrt(sig1[[2]][1,1]))
plot(x, y, type = "l", main = "Intercept - game level", cex.main = 1.5, ylim = c(0,3.3),
     xlab = "values", ylab = "density")
for(i in 2:340){
  y <- dnorm(x, mean = theta1[i,2], sd = sqrt(sig1[[2]][i,i]))
  lines(x, y, type = "l")
}
y2 <- dnorm(x, mean = 0, sd = sqrt(tau1[2]))
lines(x, y2, type = "l", col = 2, lwd = 5)


#FOUL DIFF HOME TEAM LEVEL
x <- seq(-1.5, 1.5, length = 100)
y <- dnorm(x, mean = theta2[1,1], sd = sqrt(sig2[[1]][1,1]))
plot(x, y, type = "l", main = "Foul differential - home team level", cex.main = 1.5,
     xlab = "values", ylab = "density", ylim = c(0, 2.5))
for(i in 2:39){
  y <- dnorm(x, mean = theta2[i,1], sd = sqrt(sig2[[1]][i,i]))
  lines(x, y, type = "l")
}
y2 <- dnorm(x, mean = 0, sd = sqrt(tau2[1]))
lines(x, y2, type = "l", col = 2, lwd = 5)
#legend(x = 0.025, y = 40, legend = c("posterior", "prior"), col = c(1,2), lwd = 2, bty = "n", cex = 1.3)

#INTERCEPT HOME TEAM LEVEL
x <- seq(-1.1, 1.1, length = 100)
y <- dnorm(x, mean = theta2[1,2], sd = sqrt(sig2[[2]][1,1]))
plot(x, y, type = "l", main = "Intercept - home team level", cex.main = 1.5, ylim = c(0,4),
     xlab = "values", ylab = "density")
for(i in 2:39){
  y <- dnorm(x, mean = theta2[i,2], sd = sqrt(sig2[[2]][i,i]))
  lines(x, y, type = "l")
}
y2 <- dnorm(x, mean = 0, sd = sqrt(tau2[2]))
lines(x, y2, type = "l", col = 2, lwd = 5)


#FOUL DIFF visitor LEVEL
x <- seq(-0.8, 0.8, length = 100)
y <- dnorm(x, mean = theta3[1,1], sd = sqrt(sig3[[1]][1,1]))
plot(x, y, type = "l", main = "Foul differential - home team level", cex.main = 1.5,
     xlab = "values", ylab = "density", ylim = c(0, 3))
for(i in 2:39){
  y <- dnorm(x, mean = theta3[i,1], sd = sqrt(sig3[[1]][i,i]))
  lines(x, y, type = "l")
}
y2 <- dnorm(x, mean = 0, sd = sqrt(tau3[1]))
lines(x, y2, type = "l", col = 2, lwd = 5)
#legend(x = 0.025, y = 40, legend = c("posterior", "prior"), col = c(1,2), lwd = 2, bty = "n", cex = 1.3)

#INTERCEPT visitor LEVEL
x <- seq(-.6, .6, length = 100)
y <- dnorm(x, mean = theta3[1,2], sd = sqrt(sig3[[2]][1,1]))
plot(x, y, type = "l", main = "Intercept - home team level", cex.main = 1.5, ylim = c(0,4),
     xlab = "values", ylab = "density")
for(i in 2:39){
  y <- dnorm(x, mean = theta3[i,2], sd = sqrt(sig3[[2]][i,i]))
  lines(x, y, type = "l")
}
y2 <- dnorm(x, mean = 0, sd = sqrt(tau3[2]))
lines(x, y2, type = "l", col = 2, lwd = 5)



