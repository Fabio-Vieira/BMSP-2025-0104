#This script computes the EBF values using mean, mode and the integral estimators of the prior
#in the EBF and plots the trace of the MCMC samples of the variance estimators
library(EBF)
library(rstan)
#Loading data
dat <- readRDS("data_stan.rds")
#Loading Stan model
model <- stan_model("dsem_final_model.stan")

#Fixing the initial values to the estimates presented in the paper
#so we don't have to run too many iterations
init_fun <- function(...){
  list(alpha_nu = c(3.087, 3.078, 3.258),
       alpha_lambda = c(0.734, 0.768, 0.564),
       sigma_pi = rep(0.05, 7),
       sigma_tau = rep(1e-4, 7),
       sigma = rep(1, 3),
       eta_w = rnorm(dat$N)
  )
} 

t1 <- Sys.time()
parallel::detectCores()
options(mc.cores = 4)
fitStan <- sampling(object = model, 
                    data = dat,
                    iter = 2000,
                    chains = 1,
                    init = init_fun,
                    control = list(adapt_delta = 0.9,
                                   max_treedepth = 13))
(t2 <- Sys.time() - t1)

pars <- extract(fitStan)
saveRDS(list(pars = pars,
             run_time = t2)
        , "dsem.rds")

###################################################################################
###################################################################################
###################################################################################

pars <- readRDS("dsem.rds")
pars <- pars$pars

posterior_mode <- function(posterior_samples){
  # Estimate the kernel density of the posterior samples
  kde <- density(posterior_samples)
  # Return the value corresponding to the maximum density (mode)
  return(kde$x[which.max(kde$y)])
}

###################################################################################
###################################################################################
###################################################################################

#CONDUCTING THE TEST
tau <- t(apply(pars$tau_time, c(2,3), mean))[,-c(1)]
#Getting covariance matrix
tau_samples <- aperm(pars$tau_time, c(1,3,2))
tau_var <- lapply(2:7, function(i) cov(tau_samples[,,i]))
#Random effects variance at the time level
sig_tau1 <- colMeans(pars$sigma_tau)[-c(1)]
sig_tau2 <- apply(pars$sigma_tau[,-c(1)], 2, function(i) posterior_mode(i)) 
sig_tau3 <- pars$sigma_tau[,-1]

time_mean <- EBF(tau, tau_var, sig_tau1)
time_mode <- EBF(tau, tau_var, sig_tau2)
time_integral <- EBF(tau, tau_var, sig_tau3)

###################################################################################
###################################################################################
###################################################################################

pi_ <- t(apply(pars$pi_subjs, c(2,3), mean))[,-c(1)]
#Getting covariance matrix
pi_samples <- aperm(pars$pi_subjs, c(1,3,2))
pi_var <- lapply(2:7, function(i) cov(pi_samples[,,i]))
#Random effects variance at the person level
sig_pi1 <- colMeans(pars$sigma_pi)[-c(1)]
sig_pi2 <- apply(pars$sigma_pi[,-c(1)], 2, function(i) posterior_mode(i))
sig_pi3 <- pars$sigma_pi[,-1]

person_mean <- EBF(pi_, pi_var, sig_pi1)
person_mode <- EBF(pi_, pi_var, sig_pi2)
person_integral <- EBF(pi_, pi_var, sig_pi3)

###################################################################################
###################################################################################
###################################################################################

df <- data.frame(
  person_mean = c(person_mean$EBF),
  time_mean = c(time_mean$EBF[c(6,5,4,1,2,3)]),
  person_mode = c(person_mode$EBF),
  time_mode = c(time_mode$EBF[c(6,5,4,1,2,3)]),
  person_integral = c(person_integral$EBF),
  time_integral = c(time_integral$EBF[c(6,5,4,1,2,3)])
)

###################################################################################
###################################################################################
###################################################################################

sig_tau1 <- colMeans(pars$sigma_tau)[-c(1)]
sig_tau2 <- apply(pars$sigma_tau[,-c(1)], 2, function(i) posterior_mode(i)) 

sig_pi1 <- colMeans(pars$sigma_pi)[-c(1)]
sig_pi2 <- apply(pars$sigma_pi[,-c(1)], 2, function(i) posterior_mode(i))

ci_tau1 <- apply(pars$sigma_tau[,-1], 2, function(i) quantile(i, c(0.025, 0.975)))
ci_pi1 <- apply(pars$sigma_pi[,-1], 2, function(i) quantile(i, c(0.025, 0.975)))

df_var <- data.frame(
  time_mean = sig_tau1[c(6,5,4,1,2,3)],
  person_mean = sig_pi1,
  time_mode = sig_tau2[c(6,5,4,1,2,3)],
  person_mode = sig_pi2,
  CI_lower_time = ci_tau1[1,c(6,5,4,1,2,3)],
  CI_upper_time = ci_tau1[2,c(6,5,4,1,2,3)],
  CI_lower_person = ci_pi1[1,],
  CI_upper_person = ci_pi1[2,]
)

xtable::xtable(df_var, digits = 4)

###################################################################################
###################################################################################
###################################################################################

tau_t <- pars$sigma_tau[,c(-1)]
tau_t <- pars$sigma_tau[,c(6,5,4,1,2,3)]

pi_n <- pars$sigma_pi[,-1]

par(mfrow = c(2,3))
plot(c(tau_t[,6], tau_t[,6]),
     type = "l",
     main = expression(tau[t6]^2),
     xlab = "samples",
     ylab = "values")


###################################################################################
###################################################################################
###################################################################################

pi_n <- pars$sigma_pi[,-1]
pi_n <- pars$sigma_pi[,c(6,5,4,1,2,3)]

par(mfrow = c(2,3))

plot(c(pi_n[,6], pi_n[,6]),
     type = "l",
     main = expression(tau[p6]^2),
     xlab = "samples",
     ylab = "values")
























