#In this script we create the tables with the EBFs and the estimated variances
#and the trace plots
library(EBF)
library(SpatialEpi)
library(spdep)
library(mvtnorm)
#Loading data
data(scotland)
#Obtaining the adjacent counties
map <- scotland$spatial.polygon
nb <- poly2nb(map)
n <- sapply(nb, length)
adj <- matrix(NA, nrow = max(n), ncol = 56)

for(i in 1:56){adj[1:n[i],i] <- nb[[i]]}
adj[is.na(adj)] <- 0

dl <- list(N = 56,
           E = scotland$data$expected,
           y = scotland$data$cases,
           adj = adj,
           l = n)

library(rstan)
model <- stan_model("scotlip.stan")

set.seed(1234)
#fit full Bayesian model
fit <- sampling(object = model, 
                data = dl,
                iter = 10000,
                chains = 1,
                init = "0",
                control = list(adapt_delta = 0.999, max_treedepth = 20))

############################################################
############################################################
############################################################

# extract posterior draws
pars <- extract(fit)

############################################################
############################################################
############################################################

#COMPUTE EBF FOR TESTING THE FIRST RANDOM EFFECT
#get posterior means of the random effects
gamma_est <- matrix(apply(pars$gamma, 2, mean), ncol = 1)
#get posterior covariance matrix of the random effects
gamma_cov <- cov(pars$gamma)
#get the variance estimate of the random effects
var_gamma <- mean(pars$sigma_gamma)
# the log EBF01 using the posterior mean as point estimate for the ranef variance
EBF(gamma_est, list(gamma_cov), var_gamma)
# or compute direct using dmvnorm
J <- length(gamma_est)
dmvnorm(rep(0,J),mean=gamma_est,sigma=gamma_cov,log=TRUE) -
  dmvnorm(rep(0,J),mean=rep(0,J),sigma=var_gamma*diag(J),log=TRUE)

############################################################
############################################################
############################################################

#CCOMPUTE EBF FOR TESTING THE SECOND (SPATIAL) RANDOM EFFECT (NOT POSSIBLE WITH EBF FUNCTION)
#Getting posterior means and covariance matrix of deltas
delta_est <- as.matrix(colMeans(pars$delta))
delta_cov <- cov(pars$delta)

#Build W matrix
nb <- poly2nb(map)
W <- matrix(0, nrow = 56, ncol = 56)
for(i in 1:56){
  W[nb[[i]],i] <- 1/length(nb[[i]])
}
#Number of adjacent to each county
n <- sapply(1:56, function(x) sum(nb[[x]] > 0))
A <- diag(nrow = 56) - W
A <- (A + t(A))/2
B <- diag(1/n)
B[is.infinite(B)] <- 1

#Getting variance estimate
var_delta <- mean(pars$sigma_delta)

# Obtain the estimated structured covariance matrix for the spatial random effects
ranef_cov1 <- var_delta*solve(A) %*% B %*% t(solve(A))
#Computing posterior covariance matrix
dmvnorm(rep(0, 56), mean = rep(0, 56), sigma = ranef_cov1, log = T) - 
  dmvnorm(rep(0, 56), mean = delta_est,sigma = delta_cov, log = T)

##############################################################
##############################################################
##############################################################

df <- data.frame(
  exchangeable = c(exchange_mean$EBF, exchange_mode$EBF, exchange_integral$EBF),
  spatial = c(EBF_mean, EBF_mode, EBF_integral)
)
df <- t(df)
colnames(df) <- c("mean", "mode", "integral")

##############################################################
##############################################################
##############################################################
sig_gamma1 <- mean(pars$sigma_gamma)
#Getting variance estimate
sig_delta1 <- mean(pars$sigma_delta)

ci_gamma1 <- quantile(pars$sigma_gamma, c(0.025, 0.975))
ci_delta1 <- quantile(pars$sigma_delta, c(0.025, 0.975))

df_var <- data.frame(
  exchangeable = c(sig_gamma1, ci_gamma1),
  spatial = c(sig_delta1, ci_delta1)
)
df_var <- t(df_var)
colnames(df_var) <- c("Mean", "CI_lower", "CI_upper")

xtable::xtable(df_var, digits = 4)

##############################################################
##############################################################
##############################################################

tau <- cbind(pars$sigma_gamma, pars$sigma_delta)

par(mfrow = c(1,2))
plot(tau[1:2500,1],
     type = "l",
     main = expression(tau[1]^2),
     xlab = "samples",
     ylab = "values")
plot(tau[1:2500,2],
     type = "l",
     main = expression(tau[2]^2),
     xlab = "samples",
     ylab = "values")

# check overlap of posteriors of random effects
par(mfrow = c(1,2))
#RANDOM INTERCEPT
x <- seq(-1.6, 1.6, length = 100)
y <- dnorm(x, mean = gamma_est[1], sd = sqrt(gamma_cov[1,1]))
plot(x, y, type = "l", main = "random intercepts", cex.main = 1.5, ylim = c(0,2.2),
     xlab = "values", ylab = "density")
for(i in 2:length(gamma_est)){
  y <- dnorm(x, mean = gamma_est[i], sd = sqrt(gamma_cov[i,i]))
  lines(x, y, type = "l")
}
y2 <- dnorm(x, mean = 0, sd = sqrt(var_gamma))
lines(x, y2, type = "l", col = 2, lwd = 5)

#SPATIAL RANDOM EFFECT
x <- seq(-2.6, 2.6, length = 100)
y <- dnorm(x, mean = delta_est[1], sd = sqrt(delta_cov[1,1]))
plot(x, y, type = "l", main = "spatial random effects", cex.main = 1.5, ylim = c(0,2.2),
     xlab = "values", ylab = "density")
for(i in 2:length(delta_est)){
  y <- dnorm(x, mean = delta_est[i], sd = sqrt(delta_cov[i,i]))
  lines(x, y, type = "l")
}
# the lower level random effects 'sd' differs for different random effects and therefore not plotted.

