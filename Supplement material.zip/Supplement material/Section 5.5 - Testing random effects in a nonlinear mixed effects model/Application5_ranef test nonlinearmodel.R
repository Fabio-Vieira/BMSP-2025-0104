
data("Loblolly", package = "datasets")
library("nlme")
library("lme4")
library("varTestnlme")
library("datasets")
library("mvtnorm")
library("brms")

#Bayesian fit of full model using brms
set.seed(123456)
# initial run to get model structure
nlme_Loblolly <- brm(
  bf(height ~ Asym + (R0 - Asym) * exp( - exp(lrc) * age),
     Asym ~ 1 + (1|Seed),
     R0 ~ 1 + (1|Seed),
     lrc ~ 1 + (1|Seed),
     nl = TRUE),
  data = Loblolly, family = gaussian(),
  chains = 1 # for initialization
)
#init_list <- list(b_Asym_Intercept = 100)
#plot(nlme_Loblolly)
# set flat priors for random effects variances
prior_Loblolly <- prior_summary(nlme_Loblolly)
prior_Loblolly[6+1:3,1] <- "gamma(2,.001)"
prior_Loblolly[6+10,1] <- "student_t(3, 0, 1e3)"
set.seed(123456)
nlme_Loblolly2 <- brm(
  bf(height ~ Asym + (R0 - Asym) * exp( - exp(lrc) * age),
     Asym ~ 1 + (1|Seed),
     R0 ~ 1 + (1|Seed),
     lrc ~ 1 + (1|Seed),
     nl = TRUE),
  data = Loblolly,
  family = gaussian(),
  prior = prior_Loblolly,
  chains = 1,
  iter = 20000
)
# check posteriors
plot(nlme_Loblolly2)
post.draws2 <- as.data.frame(nlme_Loblolly2)
# compute EBFs
# first random effect of Asym
var.Asym.postmean <- mean(post.draws2$sd_Seed__Asym_Intercept^2)
J <- 14 #number of random effects
postmean1 <- apply(post.draws2[,7+1:J],2,mean)
postcovm1 <- cov(post.draws2[,7+1:J])
#EBF01 computation
dmvnorm(rep(0,length(postmean1)),mean=postmean1,sigma=postcovm1,log=TRUE) - 
  dmvnorm(rep(0,length(postmean1)),sigma=var.Asym.postmean*diag(length(postmean1)),log=TRUE)
# or using EBF function
EBF(postmean1, list(postcovm1), var.Asym.postmean)

# second random effect of R0
var.R0.postmean <- mean(post.draws2$sd_Seed__R0_Intercept^2)
postmean2 <- apply(post.draws2[,7+J+1:J],2,mean)
postcovm2 <- cov(post.draws2[,7+J+1:J])
#EBF01 computation
dmvnorm(rep(0,length(postmean2)),mean=postmean2,sigma=postcovm2,log=TRUE) - 
  dmvnorm(rep(0,length(postmean2)),sigma=var.R0.postmean*diag(length(postmean2)),log=TRUE)
# or using EBF function
EBF(postmean2, list(postcovm2), var.R0.postmean)

# third random effect of lrc
var.lrc.postmean <- mean(post.draws2$sd_Seed__lrc_Intercept^2)
postmean3 <- apply(post.draws2[,7+J+J+1:J],2,mean)
postcovm3 <- cov(post.draws2[,7+J+J+1:J])
#EBF01 computation
dmvnorm(rep(0,length(postmean3)),mean=postmean3,sigma=postcovm3,log=TRUE) - 
  dmvnorm(rep(0,length(postmean3)),sigma=var.lrc.postmean*diag(length(postmean3)),log=TRUE)
# or using EBF function
EBF(postmean3, list(postcovm3), var.lrc.postmean)

# null model with only first ranef against full model
dmvnorm(rep(0,J*2),
        mean=apply(post.draws2[,7+J+1:(2*J)],2,mean),
        sigma=cov(post.draws2[,7+J+1:(2*J)]),
        log=TRUE) - 
  dmvnorm(rep(0,J*2),
          sigma=diag(c(rep(var.R0.postmean,J),rep(var.lrc.postmean,J))),
          log=TRUE)

# create traceplots
par(mfrow=c(1,3))
plot(post.draws2$sd_Seed__Asym_Intercept,type="l",main="",xlab="iterations",ylab=expression(tau*1))
plot(post.draws2$sd_Seed__R0_Intercept,type="l",main="",xlab="iterations",ylab=expression(tau*2))
plot(post.draws2$sd_Seed__lrc_Intercept,type="l",main="",xlab="iterations",ylab=expression(tau*3))

# get posterior estimates
ranef.ed.draws <- cbind(post.draws2$sd_Seed__Asym_Intercept,post.draws2$sd_Seed__R0_Intercept,post.draws2$sd_Seed__lrc_Intercept)
apply(ranef.ed.draws,2,mean)
apply(ranef.ed.draws,2,quantile,c(.025,.975))

#plot estimated posteriors of the separate random effects
par(mfrow=c(1,3))
seq1 <- seq(-15,15,length=1e4)
plot(seq1,dnorm(seq1,sd=sqrt(var.Asym.postmean)),col=2,lwd=2,ylim=c(0,.17),main="ranef Asym",ylab="density",
     xlab="values")
for(pp in 1:J){lines(seq1,dnorm(seq1,mean=postmean1[pp],sd=sqrt(postcovm1[pp,pp])))}

seq1 <- seq(-2,2,length=1e4)
plot(seq1,dnorm(seq1,sd=sqrt(var.R0.postmean)),col=2,lwd=2,ylim=c(0,1),main="ranef R0",ylab="density",
     xlab="values")
for(pp in 1:J){lines(seq1,dnorm(seq1,mean=postmean2[pp],sd=sqrt(postcovm2[pp,pp])))}

seq1 <- seq(-.2,.2,length=1e4)
plot(seq1,dnorm(seq1,sd=sqrt(var.lrc.postmean)),col=2,lwd=2,ylim=c(0,13),main="ranef lrc",ylab="density",
     xlab="values")
for(pp in 1:J){lines(seq1,dnorm(seq1,mean=postmean3[pp],sd=sqrt(postcovm3[pp,pp])))}


