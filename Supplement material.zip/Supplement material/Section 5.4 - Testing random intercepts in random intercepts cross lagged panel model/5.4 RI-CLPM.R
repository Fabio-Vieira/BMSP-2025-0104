##6.4 RI-CLPM##
load("model.test.Rdata")
library(blavaan)
library(mvtnorm)

#####section 1: RI-CLPM#####
sem_mean_riclpm <-
  
  '
# Create between components (random intercepts)

RI.PSP =~ 1*psp.mean.7 + 1*psp.mean.8 + 1*psp.mean.9 + 1*psp.mean.10 + 1*psp.mean.11
RI.SSA =~ 1*ssa.mean.7 + 1*ssa.mean.8 + 1*ssa.mean.9 + 1*ssa.mean.10 + 1*ssa.mean.11

# Estimate variance and covariance of random intercepts
  
RI.PSP ~~ RI.PSP
RI.SSA ~~ RI.SSA
RI.PSP ~~ RI.SSA
  
# Intercepts constrained

psp.mean.7 ~ psp1i*1
psp.mean.8 ~ psp1i*1
psp.mean.9 ~ psp1i*1
psp.mean.10 ~ psp1i*1
psp.mean.11 ~ psp1i*1

ssa.mean.7 ~ ssa1i*1
ssa.mean.8 ~ ssa1i*1
ssa.mean.9 ~ ssa1i*1
ssa.mean.10 ~ ssa1i*1
ssa.mean.11 ~ ssa1i*1


# Residual error constrained across waves

psp.mean.7 ~~ psp1u*psp.mean.7
psp.mean.8 ~~ psp1u*psp.mean.8
psp.mean.9 ~~ psp1u*psp.mean.9
psp.mean.10 ~~ psp1u*psp.mean.10
psp.mean.11 ~~ psp1u*psp.mean.11

ssa.mean.7 ~~ ssa1u*ssa.mean.7
ssa.mean.8 ~~ ssa1u*ssa.mean.8
ssa.mean.9 ~~ ssa1u*ssa.mean.9
ssa.mean.10 ~~ ssa1u*ssa.mean.10
ssa.mean.11 ~~ ssa1u*ssa.mean.11

# Structural paths defined (WITHIN)

ssa.mean.8 ~ A*ssa.mean.7 + C*psp.mean.7
psp.mean.8 ~ D*ssa.mean.7 + B*psp.mean.7
ssa.mean.9 ~ A*ssa.mean.8 + C*psp.mean.8
psp.mean.9 ~ D*ssa.mean.8 + B*psp.mean.8
ssa.mean.10 ~ A*ssa.mean.9 + C*psp.mean.9
psp.mean.10 ~ D*ssa.mean.9 + B*psp.mean.9
ssa.mean.11 ~ A*ssa.mean.10 + C*psp.mean.10
psp.mean.11 ~ D*ssa.mean.10 + B*psp.mean.10

# covariances defined

ssa.mean.7 ~~ psp.mean.7
ssa.mean.8 ~~ psp.mean.8
ssa.mean.9 ~~ psp.mean.9
ssa.mean.10 ~~ psp.mean.10
ssa.mean.11 ~~ psp.mean.11

'
#####section 2: blavaan (full data)#####
#n=251; 
set.seed(1015)
options(future.globals.maxSize = 6 * 1024^3)  

# start_time <- Sys.time()
bsem_mean_riclpm <- bsem(sem_mean_riclpm, seed = c(11,22,33),
                         data = model.test.dat,
                         save.lvs = TRUE,
                         dp=dpriors(ipsi="dgamma(2,0.001)[sd]", target="jags"), target = "jags")
# end_time <- Sys.time()
# diff_time <- difftime(end_time, start_time, units = "min")
save(bsem_mean_riclpm, file = "bsem_mean_riclpm.RData")
# bsem_mean_riclpm@Options[["dp"]]
# summary(bsem_mean_riclpm)

#####section 3: EBFs separately: whether all RIs=0#####
nRI <- 2

#RIs (posterior means)
postmeans <- blavInspect(bsem_mean_riclpm, "lvmeans")
sample <- nrow(postmeans) #251

#prior variance
var_priorb <- list()
var_priorb[[1]] <- coef(bsem_mean_riclpm)["RI.PSP~~RI.PSP"]  #3.137857
var_priorb[[2]] <- coef(bsem_mean_riclpm)["RI.SSA~~RI.SSA"]  #0.794861
matpriorb <- replicate(2, matrix(0, nrow = sample, ncol = sample), simplify = FALSE)
for (i in 1:nRI) {
  diag(matpriorb[[i]]) <- var_priorb[[i]]
}


#posterior variance
ri_predict <- list()
lvs <- blavPredict(bsem_mean_riclpm, type="lv") #lvs
for (i in 1:nRI) {
  ri_predict[[i]] <- do.call(rbind, lapply(lvs, function(x) x[, i]))
}
matpostb <- list()
for (i in 1:nRI) {
  matpostb[[i]] <- cov(ri_predict[[i]])
}

#EBF (log)
EBF_RI <- list()
for (i in 1:nRI) {
  #EBF RIs
  logpost <- dmvnorm(rep(0,sample), postmeans[,i], matpostb[[i]], log = TRUE)
  logprior <- dmvnorm(rep(0,sample), rep(0,sample), matpriorb[[i]], log = TRUE)
  EBF_RI[[i]] <- logpost-logprior
}
# log(EBF)
# -738.4203
# -267.3441

#####section 4: EBF jointly: whether all RIs=0#####
#prior variance
cov_priorb <- coef(bsem_mean_riclpm)["RI.PSP~~RI.SSA"]  #1.300542  
mat_joint <- matrix(c(var_priorb[[1]], cov_priorb, cov_priorb, var_priorb[[2]] ), nrow = 2)
priorcov <- kronecker(mat_joint, diag(sample)) #502*502

#posterior variance 
ri_predict_tot <- cbind(ri_predict[[1]], ri_predict[[2]]) #30000*502
postcov <- cov(ri_predict_tot) #502*502

#EBF (log) RIs jointly
logposts <- dmvnorm(rep(0,sample*2), postmeans, postcov, log = TRUE)
logpriors <- dmvnorm(rep(0,sample*2), rep(0,sample*2), priorcov, log = TRUE)
EBF_RIs <- logposts-logpriors
# log(EBF)
# -761.587

#####section 5: CIs and plots#####
##traceplot of RI variances
bmcmc <- blavInspect(bsem_mean_riclpm, "mcmc")
ripvar <- as.matrix(rbind(bmcmc[[1]][,1:2], bmcmc[[2]][,1:2], bmcmc[[3]][,1:2]))

par(mfrow = c(1,2))
plot(ripvar[,1],
     type = "l",
     main = expression(tau[1]^2),
     xlab = "samples",
     ylab = "values")
plot(ripvar[,2],
     type = "l",
     main = expression(tau[2]^2),
     xlab = "samples",
     ylab = "values")

##95%CI of RI variances
ci <- apply(ripvar, 2, function(i) quantile(i, probs = c(0.025, 0.975)))
# RI.PSP~~RI.PSP RI.SSA~~RI.SSA
# 2.5%        2.572920      0.6423526
# 97.5%       3.810014      0.9724061

##RI posterior distributions
varpost <- matrix(0, nrow = sample, ncol = nRI)
for (col_index in 1:nRI) {
  row_variances <- apply(ri_predict[[col_index]], 2, var)
  varpost[, col_index] <- row_variances
}

par(mfrow = c(1,2))
#RI1
rangeplot <- c(min(postmeans[,1])-4*sqrt(varpost[1,1]), max(postmeans[,1])+4*sqrt(varpost[1,1]))
seqx <- seq(rangeplot[1], rangeplot[2], length=1e3)

plot(seqx, dnorm(seqx, mean = postmeans[,1][1], sd=sqrt(varpost[1,1])), "l",
     xlab = "values", ylab = "density")

for (p in 2:sample) {
  lines(seqx, dnorm(seqx, mean = postmeans[,1][p], sd= sqrt(varpost[p,1])),"l")
}
#plot prior
lines(seqx, dnorm(seqx, 0, sd=sqrt(var_priorb[[1]])), col=2, lwd=4)

#RI2
rangeplot <- c(min(postmeans[,2])-4*sqrt(varpost[1,2]), max(postmeans[,2])+4*sqrt(varpost[1,2]))
seqx <- seq(rangeplot[1], rangeplot[2], length=1e3)

plot(seqx, dnorm(seqx, mean = postmeans[,2][1], sd=sqrt(varpost[1,2])), "l",
     xlab = "values", ylab = "density")

for (p in 2:sample) {
  lines(seqx, dnorm(seqx, mean = postmeans[,2][p], sd= sqrt(varpost[p,2])),"l")
}
#plot prior
lines(seqx, dnorm(seqx, 0, sd=sqrt(var_priorb[[2]])), col=2, lwd=4)
